#ifndef TESTS_MEMORY_SBRK_SIMPLE_H
#define TESTS_MEMORY_SBRK_SIMPLE_H

void test_sbrk (int amount);

#endif /* tests/memory/sbrk-oom.h */
